
export const screenshot_init = () => {}

export const screenshot_update = () => {}

export const screenshot_release = () => {}
